import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { sanitizeObject } from '../utils/security';

export interface AcademicRecord {
    degree: string;
    major: string;
    marksObtained: string;
    totalMarks: string;
    percentage: string;
    passingYear: string;
    board: string;
}

export interface Payment {
    id: string;
    amount: number;
    date: string;
    method: 'Cash' | 'Bank Transfer' | 'Cheque';
    description: string;
}

export interface Notification {
    id: string;
    studentId: string;
    studentName: string;
    type: 'Attendance' | 'Fee' | 'General';
    message: string;
    status: 'Sent' | 'Pending' | 'Failed' | 'Queued';
    date: string;
    targetNumber: string;
}

export interface Discount {
    id: string;
    amount: number;
    reason: string;
    date: string;
}


export interface Student {
    id: string;
    name: string;
    class: string;
    status: 'Active' | 'Warning' | 'Inactive';
    performance: string;
    avatar: string;
    feesPaid: number;
    feesTotal: number;
    monthlyTuition?: number;
    // Admission Form Fields
    fatherName?: string;
    fatherOccupation?: string;
    monthlyIncome?: string;
    address?: string;
    dob?: string;
    contactSelf?: string;
    contactFather?: string;
    gender?: string;
    religion?: string;
    nationality?: string;
    cnic?: string;
    discipline?: string;
    email?: string;
    campus?: string;
    isOrphan?: string;
    whatsappNumber?: string;
    admissionDate?: string;
    admissionFees?: number;
    monthlyFees?: number;
    securityFees?: number;
    miscellaneousCharges?: number;
    academicRecords?: AcademicRecord[];
    documents?: Record<string, string>;
    manualId?: string;
    paymentHistory?: Payment[];
    discounts?: Discount[];
}

export interface Teacher {
    id: string;
    name: string;
    subject: string;
    classes: string[];
    status: 'Active' | 'On Leave';
    avatar: string;
    // Teacher Details
    cnic?: string;
    address?: string;
    dob?: string;
    gender?: string;
    religion?: string;
    nationality?: string;
    phone?: string;
    email?: string;
    qualification?: string;
    experience?: string;
    joiningDate?: string;
    campus?: string;
    whatsappNumber?: string;
    fatherName?: string;
    husbandName?: string;
    maritalStatus?: 'Single' | 'Married' | 'Divorced' | 'Widowed';
    baseSalary?: number;
    // Login & Access Control
    username?: string;
    password?: string;
    permissions?: string[];
    role?: string;
    documents?: Record<string, string>;
}

export interface SalarySlip {
    id: string;
    teacherId: string;
    month: string;
    year: number;
    baseSalary: number;
    allowances: { type: string; amount: number }[];
    deductions: { type: string; amount: number }[];
    bonus?: number;
    netSalary: number;
    status: 'Paid' | 'Pending';
    paidDate?: string;
    paymentMethod?: 'Cash' | 'Bank Transfer' | 'Cheque';
}

export interface Expense {
    id: string;
    title: string;
    category: 'Utilities' | 'Rent' | 'Stationery' | 'Maintenance' | 'Miscellaneous' | 'Events';
    amount: number;
    date: string;
    description?: string;
}


export interface SchoolSettings {
    schoolName: string;
    subTitle: string;
    location: string;
    logo1: string | null;
    logo2: string | null;
    academicSession: string;
    effectiveDate: string;
    aiApiKey?: string;
    aiTone?: 'Professional' | 'Polite' | 'Strict' | 'Supportive';
    primaryColor?: string;
    dashboardTheme?: 'Light' | 'Dark' | 'Premium';
    themeColors?: {
        primary: string;
        secondary: string;
        accent: string;
        borderRadius?: string;
        glassIntensity?: string;
    };
}

export interface Campus {
    id: string;
    name: string;
    location: string;
    contact?: string;
    principalName?: string;
    email?: string;
    idPrefix?: string;
    type?: 'School' | 'College' | 'Both';
    status?: 'Active' | 'Inactive';
    capacity?: number;
}

export interface AuditLog {
    id: string;
    user: string;
    action: string;
    timestamp: string;
    details: string;
    type: 'Security' | 'Academic' | 'Financial' | 'System';
}

export interface AttendanceRecord {
    studentId: string;
    status: 'Present' | 'Absent' | 'Late' | 'Leave';
}

export interface Attendance {
    date: string;
    class: string;
    campus: string;
    records: AttendanceRecord[];
}

export interface TimetableSlot {
    subject: string;
    teacherId: string;
    startTime: string;
    endTime: string;
    isElective?: boolean;
    secondarySubject?: string;
    secondaryTeacherId?: string;
    tertiarySubject?: string;
    tertiaryTeacherId?: string;
}

export interface PeriodTime {
    label: string;
    start: string;
    end: string;
    friStart: string;
    friEnd: string;
    duration: string;
    isBreak?: boolean;
}

export interface WeeklyTimetable {
    [day: string]: TimetableSlot[];
}

export interface Exam {
    id: string;
    name: string;
    classes: string[];
    date: string;
    status: 'In Progress' | 'Finalized';
    createdAt: string;
}

export interface StudentExamResult {
    studentId: string;
    examId: string;
    className: string;
    marks: Record<string, { obtained: number; total: number }>; // subject -> { obtained, total }
    totalObtained: number;
    totalPossible: number;
    percentage: number;
    grade: string;
    position: number | null;
    remarks?: string;
}

interface AppState {
    students: Student[];
    teachers: Teacher[];
    settings: SchoolSettings;
    attendance: Attendance[];
    feeStructure: Record<string, number>;
    classes: string[];
    periodSettings: Record<string, PeriodTime[]>;
    updatePeriodSettings: (settings: Record<string, PeriodTime[]>) => void;
    addClass: (name: string, fee: number) => void;
    updateClass: (oldName: string, newName: string, fee: number) => void;
    deleteClass: (name: string) => void;
    addStudent: (s: Partial<Student>) => void;
    updateStudent: (id: string, updates: Partial<Student>) => void;
    deleteStudent: (id: string) => void;
    addTeacher: (t: Partial<Teacher>) => void;
    updateTeacher: (id: string, updates: Partial<Teacher>) => void;
    deleteTeacher: (id: string) => void;
    updateSettings: (s: Partial<SchoolSettings>) => void;
    markAttendance: (a: Attendance) => void;
    updateFeeStructure: (updates: Record<string, number>) => void;
    classSubjects: Record<string, string[]>;
    classInCharge: Record<string, string>;
    subjectTeachers: Record<string, Record<string, string>>; // Class -> { Subject: TeacherId }
    timetables: Record<string, WeeklyTimetable>; // Class -> WeeklyTimetable
    updateClassSubjects: (className: string, subjects: string[]) => void;
    updateClassInCharge: (className: string, teacherId: string) => void;
    assignSubjectTeacher: (className: string, subject: string, teacherId: string) => void;
    updateTimetable: (className: string, timetable: WeeklyTimetable) => void;
    updateAllTimetables: (newTimetables: Record<string, WeeklyTimetable>) => void;
    promoteStudents: (fromClass: string, toClass: string) => void;
    exams: Exam[];
    examResults: StudentExamResult[];
    addExam: (exam: Partial<Exam>) => void;
    deleteExam: (id: string) => void;
    inputMarks: (examId: string, className: string, studentId: string, subject: string, obtained: number, total: number) => void;
    finalizeResults: (examId: string, className: string) => void;
    currentUser: { id: string, name: string, role: string } | null;
    login: (id: string, role: string) => boolean;
    logout: () => void;
    notifications: Notification[];
    sendNotification: (studentId: string, type: 'Attendance' | 'Fee' | 'General', message: string) => void;
    triggerFeeReminders: (className?: string, studentId?: string) => void;
    auditLogs: AuditLog[];
    addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp'>) => void;

    // Finance System
    expenses: Expense[];
    salarySlips: SalarySlip[];
    addExpense: (e: Omit<Expense, 'id'>) => void;
    deleteExpense: (id: string) => void;
    generateSalarySlips: (month: string, year: number) => void;
    updateSalarySlip: (id: string, updates: Partial<SalarySlip>) => void;

    // Backup & Restore
    importBackup: (data: any) => boolean;

    // Campus Management
    campuses: Campus[];
    addCampus: (c: Omit<Campus, 'id'>) => void;
    updateCampus: (id: string, updates: Partial<Campus>) => void;
    deleteCampus: (id: string) => void;
}

const StoreContext = createContext<AppState | undefined>(undefined);

const INITIAL_STUDENTS: Student[] = [
    {
        id: 'STU-001',
        name: 'Zainab Ahmed',
        class: 'Grade 10-A',
        status: 'Active',
        performance: '92%',
        avatar: 'Z',
        feesPaid: 2400,
        feesTotal: 3000,
        whatsappNumber: '03001234567',
        contactFather: '03001234567'
    },
    {
        id: 'STU-002',
        name: 'Hamza Khan',
        class: 'Grade 12-C',
        status: 'Active',
        performance: '88%',
        avatar: 'H',
        feesPaid: 3000,
        feesTotal: 3000,
        whatsappNumber: '03007654321',
        contactFather: '03007654321'
    },
];

const INITIAL_TEACHERS: Teacher[] = [
    { id: 'TCH-ERUM', name: 'Ms. Erum', subject: 'English', classes: ['Class 1', '1st Year', '2nd Year'], status: 'Active', avatar: 'E' },
    { id: 'TCH-RAZIA', name: 'Ms. Razia', subject: 'Urdu & Islamiat', classes: ['Class 1', 'Class 2', 'Class 3'], status: 'Active', avatar: 'R' },
    { id: 'TCH-IRUM', name: 'Ms. Irum', subject: 'English', classes: ['Class 1', 'Class 2', 'Class 4'], status: 'Active', avatar: 'I' },
    { id: 'TCH-ZARA', name: 'Ms. Zara', subject: 'Science', classes: ['Class 1', 'Class 5', '6th Boys', '9th S Boys', '1st Year Girls', '2nd Year Girls'], status: 'Active', avatar: 'Z' },
    { id: 'TCH-MARIA', name: 'Ms. Maria', subject: 'Math', classes: ['Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'], status: 'Active', avatar: 'M' },
    { id: 'TCH-MARYAM', name: 'Ms. Maryam', subject: 'Computer/SST', classes: ['Class 2', 'Class 3', 'Class 4'], status: 'Active', avatar: 'M' },
    { id: 'TCH-AIMEN', name: 'Ms. Aimen', subject: 'Science', classes: ['Class 2'], status: 'Active', avatar: 'A' },
    { id: 'TCH-AMNA', name: 'Ms. Amna', subject: 'English/Science', classes: ['Class 3', 'Class 5', '7th Boys', '6th Girls', '7th Girls'], status: 'Active', avatar: 'A' },
    { id: 'TCH-ANEELA', name: 'Ms. Aneela', subject: 'Islamiat', classes: ['Class 4', 'Class 5', '6th Boys', '7th Boys', '6th Girls', '7th Girls'], status: 'Active', avatar: 'A' },
    { id: 'TCH-SAIMA', name: 'Ms. Saima', subject: 'Science/Physics', classes: ['Class 4', '7th Boys', '9th S Boys', 'Girls 9th'], status: 'Active', avatar: 'S' },
    { id: 'TCH-SAMRA', name: 'Ms. Samra', subject: 'Urdu', classes: ['Class 4', 'Class 5', '6th Boys', '7th Boys', '6th Girls', '7th Girls'], status: 'Active', avatar: 'S' },
    { id: 'TCH-ALEENA', name: 'Ms. Aleena', subject: 'Computer', classes: ['Class 4', 'Class 5'], status: 'Active', avatar: 'A' },
    { id: 'TCH-FIZA', name: 'Ms. Fiza', subject: 'Biology/Chemistry', classes: ['Class 5', '9th J Boys', '9th S Boys', '7th Girls', 'Girls 9th'], status: 'Active', avatar: 'F' },
    { id: 'TCH-ALISHBA', name: 'Ms. Alishba A', subject: 'English', classes: ['6th Boys'], status: 'Active', avatar: 'A' },
    { id: 'TCH-HAMID', name: 'Mr. Hamid', subject: 'Computer', classes: ['6th Boys', '7th Boys', '9th J Boys', '9th S Boys'], status: 'Active', avatar: 'H' },
    { id: 'TCH-NIMRAH', name: 'Ms. Nimrah', subject: 'English/SST', classes: ['6th Boys', '9th S Boys', '10th Boys', '1st Year Boys', '6th Girls', 'Girls 9th'], status: 'Active', avatar: 'N' },
    { id: 'TCH-SMARYAM', name: 'Ms. S Maryam', subject: 'Math', classes: ['6th Boys', '9th S Boys', '10th Boys', '7th Girls', 'Girls 9th'], status: 'Active', avatar: 'S' },
    { id: 'TCH-USMAN', name: 'Mr. Usman', subject: 'Science/Chemistry', classes: ['7th Boys', '10th Boys', '1st Year Boys', '2nd Year Boys', 'Girls 9th', '1st Year Girls', '2nd Year Girls'], status: 'Active', avatar: 'U' },
    { id: 'TCH-QARI', name: 'Qari Sb', subject: 'Islamiat', classes: ['9th J Boys', '9th S Boys', '10th Boys', '1st Year Boys', 'Girls 9th', '1st Year Girls'], status: 'Active', avatar: 'Q' },
    { id: 'TCH-MANSOOR', name: 'Mr. Mansoor', subject: 'Physics/Math', classes: ['9th J Boys', '10th Boys', '1st Year Boys', '6th Girls', '1st Year Girls'], status: 'Active', avatar: 'M' },
    { id: 'TCH-UZMA', name: 'Ms. Uzma', subject: 'Urdu', classes: ['9th J Boys', '10th Boys', '1st Year Boys', '2nd Year Boys', '1st Year Girls', '2nd Year Girls'], status: 'Active', avatar: 'U' },
    { id: 'TCH-IRUMS', name: 'Ms. Irum S', subject: 'Urdu/PST', classes: ['9th S Boys', '10th Boys', '2nd Year Boys', 'Girls 9th', '2nd Year Girls'], status: 'Active', avatar: 'I' },
    { id: 'TCH-SURIYA', name: 'Ms. Suriya', subject: 'Math', classes: ['7th Boys', '1st Year Boys', '2nd Year Boys', '7th Girls', '1st Year Girls', '2nd Year Girls'], status: 'Active', avatar: 'S' },
    { id: 'TCH-MUBEEN', name: 'Mr. Mubeen', subject: 'Computer', classes: ['1st Year Boys', '2nd Year Boys', '10th Girls', '1st Year Girls', '2nd Year Girls'], status: 'Active', avatar: 'M' },
    { id: 'TCH-ABASIT', name: 'Mr. A Basit', subject: 'Physics', classes: ['2nd Year Boys', '2nd Year Girls'], status: 'Active', avatar: 'A' },
];


const INITIAL_SETTINGS: SchoolSettings = {
    schoolName: "PIONEER'S SUPERIOR",
    subTitle: "Institute Of Higher Secondary Education, Attock",
    location: "Mirza Road, Attock City",
    logo1: "/logo1.png",
    logo2: "/logo2.png",
    academicSession: "2023-2024",
    effectiveDate: "19-11-2023",
    themeColors: {
        primary: '#003366',
        secondary: '#0ea5e9',
        accent: '#fbbf24',
        borderRadius: '2.5rem',
        glassIntensity: '0.98'
    }
};

const INITIAL_CAMPUSES: Campus[] = [
    {
        id: 'CAMP-MANZOOR',
        name: 'Dr Manzoor Campus',
        location: 'Attock City',
        idPrefix: 'MH',
        principalName: 'Dr. Mansoor',
        status: 'Active',
        type: 'Both'
    },
    {
        id: 'CAMP-SHAMIM',
        name: 'Shamim Campus',
        location: 'Attock City',
        idPrefix: 'SF',
        principalName: 'Ms. Shamim',
        status: 'Active',
        type: 'School'
    },
    {
        id: 'CAMP-SHAWAR',
        name: 'Shawar Campus',
        location: 'Attock City',
        idPrefix: 'SN',
        principalName: 'Mr. Shawar',
        status: 'Active',
        type: 'College'
    }
];

const INITIAL_FEE_STRUCTURE: Record<string, number> = {
    'PG': 2500,
    'Nursery': 2500,
    'KG': 2500,
    'Class 1': 3000,
    'Class 2': 3000,
    'Class 3': 3000,
    'Class 4': 3000,
    'Class 5': 3000,
    'Class 6 (Boys)': 3500,
    'Class 6 (Girls)': 3500,
    'Class 7 (Boys)': 3500,
    'Class 7 (Girls)': 3500,
    'Class 8': 3500,
    'Class 9th J (Boys)': 4000,
    'Class 9th S (Boys)': 4000,
    'Class 9th (Girls)': 4000,
    'Class 10th (Boys)': 4500,
    'Class 10th (Girls)': 4500,
    '1st Year (Boys)': 5500,
    '1st Year (Girls)': 5500,
    '2nd Year (Boys)': 5500,
    '2nd Year (Girls)': 5500,
    'General': 3000
};

const DEFAULT_SCHOOL_CLASSES = [
    'PG', 'Nursery', 'KG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5',
    'Class 6 (Boys)', 'Class 6 (Girls)', 'Class 7 (Boys)', 'Class 7 (Girls)', 'Class 8',
    'Class 9th J (Boys)', 'Class 9th S (Boys)', 'Class 9th (Girls)', 'Class 10th (Boys)', 'Class 10th (Girls)'
];
const DEFAULT_COLLEGE_CLASSES = ['1st Year (Boys)', '1st Year (Girls)', '2nd Year (Boys)', '2nd Year (Girls)'];

export const DEFAULT_PERIODS: PeriodTime[] = [
    { label: 'ASSM', start: '08:00', end: '08:15', duration: '15 Min', friStart: '07:20', friEnd: '07:35' },
    { label: '1', start: '08:15', end: '09:00', duration: '45 Min', friStart: '07:35', friEnd: '08:10' },
    { label: '2', start: '09:00', end: '09:45', duration: '45 Min', friStart: '08:10', friEnd: '08:45' },
    { label: '3', start: '09:45', end: '10:30', duration: '45 Min', friStart: '08:45', friEnd: '09:20' },
    { label: '4', start: '10:30', end: '11:15', duration: '45 Min', friStart: '09:20', friEnd: '09:55' },
    { label: 'BRK', start: '11:15', end: '11:35', duration: '20 Min', friStart: '09:55', friEnd: '10:10', isBreak: true },
    { label: '6', start: '11:35', end: '12:20', duration: '45 Min', friStart: '10:10', friEnd: '10:45' },
    { label: '7', start: '12:20', end: '01:05', duration: '45 Min', friStart: '10:45', friEnd: '11:20' }
];

export const StoreProvider = ({ children }: { children: ReactNode }) => {
    const [students, setStudents] = useState<Student[]>(() => {
        const saved = localStorage.getItem('edunova_students');
        return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
    });

    const [teachers, setTeachers] = useState<Teacher[]>(() => {
        const saved = localStorage.getItem('edunova_teachers');
        return saved ? JSON.parse(saved) : INITIAL_TEACHERS;
    });


    const [settings, setSettings] = useState<SchoolSettings>(() => {
        const saved = localStorage.getItem('edunova_settings');
        if (saved) {
            const parsed = JSON.parse(saved);
            return {
                ...INITIAL_SETTINGS,
                ...parsed,
                logo1: parsed.logo1 || INITIAL_SETTINGS.logo1,
                logo2: parsed.logo2 || INITIAL_SETTINGS.logo2
            };
        }
        return INITIAL_SETTINGS;
    });

    const [attendance, setAttendance] = useState<Attendance[]>(() => {
        const saved = localStorage.getItem('edunova_attendance');
        return saved ? JSON.parse(saved) : [];
    });

    const [feeStructure, setFeeStructure] = useState<Record<string, number>>(() => {
        const saved = localStorage.getItem('edunova_fees');
        return saved ? JSON.parse(saved) : INITIAL_FEE_STRUCTURE;
    });

    const [classSubjects, setClassSubjects] = useState<Record<string, string[]>>(() => {
        const saved = localStorage.getItem('edunova_class_subjects');
        if (saved) return JSON.parse(saved);

        return {
            'PG': ['English', 'Urdu', 'Math', 'GK'],
            'Nursery': ['English', 'Urdu', 'Math', 'GK'],
            'KG': ['English', 'Urdu', 'Math', 'GK'],
            'Class 1': ['English', 'Urdu', 'Computer', 'Science', 'Math', 'Islamiat'],
            'Class 2': ['Urdu', 'English', 'Islamiat', 'Math', 'Computer', 'Science'],
            'Class 3': ['Science', 'Math', 'English', 'Urdu', 'Islamiat', 'Computer'],
            'Class 4': ['Math', 'Islamiat', 'Science', 'English', 'Urdu', 'Computer', 'S.S.T'],
            'Class 5': ['Islamiat', 'Urdu', 'English', 'SST', 'Math', 'Science', 'Computer'],
            'Class 6 (Boys)': ['Science', 'English', 'Islamiat', 'Computer', 'S.S.T', 'Math', 'Urdu'],
            'Class 6 (Girls)': ['Science', 'English', 'Islamiat', 'Computer', 'S.S.T', 'Math', 'Urdu'],
            'Class 7 (Boys)': ['Science', 'Computer', 'Urdu', 'Islamiat', 'English', 'S.S.T', 'Math'],
            'Class 7 (Girls)': ['Science', 'Computer', 'Urdu', 'Islamiat', 'English', 'S.S.T', 'Math'],
            'Class 9th J (Boys)': ['Biology', 'Computer', 'Islamiat', 'Physics', 'Urdu', 'Chemistry', 'Math', 'English'],
            'Class 9th S (Boys)': ['Biology', 'Computer', 'Islamiat', 'Physics', 'Urdu', 'Chemistry', 'Math', 'English'],
            'Class 9th (Girls)': ['Biology', 'Computer', 'Islamiat', 'Physics', 'Urdu', 'Chemistry', 'Math', 'English'],
            'Class 10th (Boys)': ['Islamiat', 'Chemistry', 'Urdu', 'Physics', 'Math', 'English', 'Biology', 'P.St'],
            'Class 10th (Girls)': ['Islamiat', 'Chemistry', 'Urdu', 'Physics', 'Math', 'English', 'Biology', 'P.St'],
            '1st Year (Boys)': ['Urdu', 'Physics', 'Islamiat', 'Math', 'Biology', 'Computer', 'Chemistry', 'English'],
            '1st Year (Girls)': ['Urdu', 'Physics', 'Islamiat', 'Math', 'Biology', 'Computer', 'Chemistry', 'English'],
            '2nd Year (Boys)': ['Physics', 'Urdu', 'Math', 'Biology', 'Computer', 'P.St', 'English', 'Chemistry'],
            '2nd Year (Girls)': ['Physics', 'Urdu', 'Math', 'Biology', 'Computer', 'P.St', 'English', 'Chemistry']
        };
    });

    const [classInCharge, setClassInCharge] = useState<Record<string, string>>(() => {
        const saved = localStorage.getItem('edunova_class_incharge');
        return saved ? JSON.parse(saved) : {};
    });

    const [subjectTeachers, setSubjectTeachers] = useState<Record<string, Record<string, string>>>(() => {
        const saved = localStorage.getItem('edunova_subject_teachers');
        const initial = {
            'Class 1': { 'English': 'TCH-ERUM', 'Urdu & Islamiat': 'TCH-RAZIA', 'Computer': 'TCH-IRUM', 'Science': 'TCH-ZARA', 'Math': 'TCH-MARIA' },
            'Class 2': { 'Urdu & Islamiat': 'TCH-RAZIA', 'English': 'TCH-IRUM', 'Math': 'TCH-MARIA', 'Computer': 'TCH-MARYAM', 'Science': 'TCH-AIMEN' },
            'Class 3': { 'Science': 'TCH-AMNA', 'Math & English': 'TCH-MARIA', 'Urdu & Islamiat': 'TCH-RAZIA', 'Computer': 'TCH-MARYAM' },
            'Class 4': { 'Math': 'TCH-MARIA', 'Islamiat': 'TCH-ANEELA', 'Science': 'TCH-SAIMA', 'English': 'TCH-IRUM', 'Urdu': 'TCH-SAMRA', 'Computer': 'TCH-ALEENA', 'S.S.T': 'TCH-MARYAM' },
            'Class 5': { 'Islamiat': 'TCH-ANEELA', 'Urdu': 'TCH-SAMRA', 'English': 'TCH-AMNA', 'S.S.T': 'TCH-FIZA', 'Math': 'TCH-MARIA', 'Science': 'TCH-ZARA', 'Computer': 'TCH-ALEENA' },
            'Class 6 (Boys)': { 'Science': 'TCH-ZARA', 'English': 'TCH-ALISHBA', 'Islamiat': 'TCH-ANEELA', 'Computer': 'TCH-HAMID', 'S.S.T': 'TCH-NIMRAH', 'Math': 'TCH-SMARYAM', 'Urdu': 'TCH-SAMRA' },
            'Class 7 (Boys)': { 'Science': 'TCH-USMAN', 'Computer': 'TCH-HAMID', 'Urdu': 'TCH-SAMRA', 'Islamiat': 'TCH-ANEELA', 'English': 'TCH-AMNA', 'S.S.T': 'TCH-SAIMA', 'Math': 'TCH-SURIYA' },
            'Class 9th J (Boys)': { 'Biology & Chemistry': 'TCH-FIZA', 'Computer': 'TCH-HAMID', 'Islamiat': 'TCH-QARI', 'Physics & Math': 'TCH-MANSOOR', 'Urdu': 'TCH-UZMA' },
            'Class 9th S (Boys)': { 'English': 'TCH-NIMRAH', 'Chemistry': 'TCH-ZARA', 'Biology': 'TCH-FIZA', 'Computer': 'TCH-HAMID', 'Islamiat': 'TCH-QARI', 'Physics': 'TCH-SAIMA', 'Urdu': 'TCH-IRUMS', 'Math': 'TCH-SMARYAM' },
            'Class 10th (Boys)': { 'Islamiat': 'TCH-QARI', 'Chemistry': 'TCH-USMAN', 'Urdu': 'TCH-UZMA', 'Physics': 'TCH-MANSOOR', 'Math': 'TCH-SMARYAM', 'English': 'TCH-NIMRAH', 'PST': 'TCH-IRUMS' },
            '1st Year (Boys)': { 'Urdu': 'TCH-UZMA', 'Physics': 'TCH-MANSOOR', 'Islamiat': 'TCH-QARI', 'Math': 'TCH-SURIYA', 'Computer': 'TCH-MUBEEN', 'English': 'TCH-ERUM', 'Civics/Islamiat E': 'TCH-IRUMS', 'Education': 'TCH-NIMRAH', 'Chemistry': 'TCH-USMAN' },
            '2nd Year (Boys)': { 'Physics': 'TCH-ABASIT', 'Urdu': 'TCH-UZMA', 'Math': 'TCH-SURIYA', 'Biology': 'TCH-ZARA', 'Computer': 'TCH-MUBEEN', 'PST': 'TCH-IRUMS', 'English': 'TCH-ERUM', 'Chemistry': 'TCH-USMAN' },
            'Class 6 (Girls)': { 'Urdu': 'TCH-SAMRA', 'Math': 'TCH-SMARYAM', 'S.S.T': 'TCH-NIMRAH', 'Science': 'TCH-ZARA', 'Islamiat': 'TCH-ANEELA', 'English': 'TCH-AMNA', 'Computer': 'TCH-MANSOOR' },
            'Class 7 (Girls)': { 'S.S.T': 'TCH-SAIMA', 'Science': 'TCH-FIZA', 'Computer': 'TCH-SMARYAM', 'English': 'TCH-AMNA', 'Math': 'TCH-SURIYA', 'Urdu': 'TCH-SAMRA', 'Islamiat': 'TCH-ANEELA' },
            'Class 9th (Girls)': { 'Math': 'TCH-SMARYAM', 'English': 'TCH-NIMRAH', 'Chemistry': 'TCH-USMAN', 'Physics': 'TCH-SAIMA', 'Islamiat': 'TCH-QARI', 'Biology': 'TCH-FIZA', 'Urdu': 'TCH-IRUMS' },
            'Class 10th (Girls)': { 'Computer': 'TCH-MUBEEN' },
            '1st Year (Girls)': { 'Math': 'TCH-SURIYA', 'Biology': 'TCH-ZARA', 'Computer': 'TCH-MUBEEN', 'Islamiat': 'TCH-QARI', 'Chemistry': 'TCH-USMAN', 'Physics': 'TCH-MANSOOR', 'Urdu': 'TCH-UZMA', 'English': 'TCH-ERUM' },
            '2nd Year (Girls)': { 'Physics': 'TCH-ABASIT', 'Math': 'TCH-SURIYA', 'Biology': 'TCH-ZARA', 'Computer': 'TCH-MUBEEN', 'PST': 'TCH-IRUMS', 'English': 'TCH-ERUM', 'Chemistry': 'TCH-USMAN', 'Urdu': 'TCH-UZMA' }
        };

        if (saved) {
            const parsed = JSON.parse(saved);
            // Merge defaults with saved to make sure new classes have subjects
            return { ...initial, ...parsed };
        }
        return initial;
    });

    useEffect(() => {
        // One-time sync to ensure classes state matches our new structure
        const synced = localStorage.getItem('curriculum_synced_v7');
        if (!synced) {
            setClasses([...DEFAULT_SCHOOL_CLASSES, ...DEFAULT_COLLEGE_CLASSES]);
            localStorage.setItem('curriculum_synced_v7', 'true');
        }
    }, []);

    const [timetables, setTimetables] = useState<Record<string, WeeklyTimetable>>(() => {
        const saved = localStorage.getItem('edunova_timetables');
        return saved ? JSON.parse(saved) : {};
    });

    const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
        const saved = localStorage.getItem('edunova_audit_logs');
        return saved ? JSON.parse(saved) : [];
    });

    const [classes, setClasses] = useState<string[]>(() => {
        const saved = localStorage.getItem('edunova_classes');
        if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
        return [...DEFAULT_SCHOOL_CLASSES, ...DEFAULT_COLLEGE_CLASSES];
    });

    const [periodSettings, setPeriodSettings] = useState<Record<string, PeriodTime[]>>(() => {
        const saved = localStorage.getItem('edunova_period_settings_v2');
        if (saved) return JSON.parse(saved);

        const oldSaved = localStorage.getItem('edunova_period_settings');
        const oldPeriods = oldSaved ? JSON.parse(oldSaved) : DEFAULT_PERIODS;

        return {
            primary: [...oldPeriods],
            boys: [...oldPeriods],
            girls: [...oldPeriods]
        };
    });

    const [exams, setExams] = useState<Exam[]>(() => {
        const saved = localStorage.getItem('edunova_exams_v2'); // Changed from edunova_exams to match new consolidated key
        return saved ? JSON.parse(saved) : [];
    });

    const [examResults, setExamResults] = useState<StudentExamResult[]>(() => {
        const saved = localStorage.getItem('edunova_exam_results_v2');
        return saved ? JSON.parse(saved) : [];
    });

    const [notifications, setNotifications] = useState<Notification[]>(() => {
        const saved = localStorage.getItem('edunova_notifications');
        return saved ? JSON.parse(saved) : [];
    });

    const [campuses, setCampuses] = useState<Campus[]>(() => {
        const saved = localStorage.getItem('edunova_campuses');
        return saved ? JSON.parse(saved) : INITIAL_CAMPUSES;
    });

    useEffect(() => {
        // Migration for specific campus names requested by user
        const campusMigration = localStorage.getItem('campus_migration_v1');
        if (!campusMigration) {
            setCampuses(INITIAL_CAMPUSES);
            localStorage.setItem('campus_migration_v1', 'true');
        }
    }, []);

    const updatePeriodSettings = (settings: Record<string, PeriodTime[]>) => {
        setPeriodSettings(settings);
    };

    useEffect(() => {
        try {
            localStorage.setItem('edunova_students', JSON.stringify(students));
            localStorage.setItem('edunova_teachers', JSON.stringify(teachers));
            localStorage.setItem('edunova_settings', JSON.stringify(settings));
            localStorage.setItem('edunova_attendance', JSON.stringify(attendance));
            localStorage.setItem('edunova_fees', JSON.stringify(feeStructure));
            localStorage.setItem('edunova_classes', JSON.stringify(classes));
            localStorage.setItem('edunova_period_settings_v2', JSON.stringify(periodSettings));
            localStorage.setItem('edunova_class_subjects', JSON.stringify(classSubjects));
            localStorage.setItem('edunova_class_incharge', JSON.stringify(classInCharge));
            localStorage.setItem('edunova_subject_teachers', JSON.stringify(subjectTeachers));
            localStorage.setItem('edunova_timetables', JSON.stringify(timetables));
            localStorage.setItem('edunova_exams_v2', JSON.stringify(exams));
            localStorage.setItem('edunova_exam_results_v2', JSON.stringify(examResults));
            localStorage.setItem('edunova_notifications', JSON.stringify(notifications));
            localStorage.setItem('edunova_audit_logs', JSON.stringify(auditLogs));
            localStorage.setItem('edunova_campuses', JSON.stringify(campuses));
        } catch (err) {
            console.error('CRITICAL: LocalStorage Full or Corrupted. Changes may not persist.', err);
        }
    }, [
        students, teachers, settings, attendance, feeStructure,
        classes, periodSettings, classSubjects, classInCharge,
        subjectTeachers, timetables, exams, examResults, notifications, auditLogs, campuses
    ]);

    // Apply Theme Engine
    useEffect(() => {
        if (settings.themeColors) {
            const root = document.documentElement;
            root.style.setProperty('--brand-primary', settings.themeColors.primary);
            root.style.setProperty('--brand-secondary', settings.themeColors.secondary);
            root.style.setProperty('--brand-accent', settings.themeColors.accent);
            root.style.setProperty('--brand-text', settings.themeColors.primary);
            root.style.setProperty('--brand-radius', settings.themeColors.borderRadius || '2.5rem');
            root.style.setProperty('--brand-glass', settings.themeColors.glassIntensity || '0.98');

            // Generate subtle variations for better aesthetics
            root.style.setProperty('--brand-primary-light', `${settings.themeColors.primary}20`);
            root.style.setProperty('--brand-secondary-light', `${settings.themeColors.secondary}20`);
        }
    }, [settings.themeColors]);

    const promoteStudents = (fromClass: string, toClass: string) => {
        setStudents(prev => prev.map(s => s.class === fromClass ? { ...s, class: toClass } : s));
    };

    const addStudent = (s: Partial<Student>) => {
        const cleanData = sanitizeObject(s);
        const newStudent: Student = {
            ...cleanData as Student,
            id: cleanData.id || `ADM-${Date.now().toString().slice(-6)}`,
            status: 'Active',
            performance: 'N/A',
            feesPaid: s.feesPaid ?? 0,
            feesTotal: s.feesTotal ?? 0,
            avatar: s.avatar || (s.name || 'S').charAt(0),
            admissionFees: s.admissionFees || 0,
            monthlyFees: s.monthlyFees || 0,
            securityFees: s.securityFees || 0,
            miscellaneousCharges: s.miscellaneousCharges || 0,
            paymentHistory: [],
            discounts: []
        };
        setStudents(prev => [...prev, newStudent]);
    };

    const updateStudent = (oldId: string, updates: Partial<Student>) => {
        const cleanUpdates = sanitizeObject(updates);
        const newId = cleanUpdates.id;

        setStudents(prev => prev.map(s => s.id === oldId ? { ...s, ...cleanUpdates } : s));

        // If ID has changed, propagate to other records
        if (newId && newId !== oldId) {
            setAttendance((prev: Attendance[]) => prev.map((a: Attendance) => ({
                ...a,
                records: a.records.map((r: AttendanceRecord) => r.studentId === oldId ? { ...r, studentId: newId } : r)
            })));

            setExamResults((prev: StudentExamResult[]) => prev.map((r: StudentExamResult) => r.studentId === oldId ? { ...r, studentId: newId } : r));

            setNotifications((prev: Notification[]) => prev.map((n: Notification) => n.studentId === oldId ? { ...n, studentId: newId } : n));
        }
    };

    const deleteStudent = (id: string) => {
        setStudents(prev => prev.filter(s => s.id !== id));
    };

    const addTeacher = (t: Partial<Teacher>) => {
        const cleanData = sanitizeObject(t);
        const newTeacher: Teacher = {
            id: `PST-${Date.now().toString().slice(-6)}`,
            name: '',
            subject: '',
            phone: '',
            avatar: (cleanData.name || 'P').charAt(0),
            status: 'Active',
            classes: [],
            whatsappNumber: '',
            email: '',
            fatherName: '',
            password: '',
            username: '',
            permissions: [],
            ...cleanData
        } as Teacher;

        // Ensure avatar is preserved if present in t, otherwise the character is used
        if (t.avatar) {
            newTeacher.avatar = t.avatar;
        }
        setTeachers(prev => [...prev, newTeacher]);
    };

    const updateTeacher = (id: string, updates: Partial<Teacher>) => {
        const cleanUpdates = sanitizeObject(updates);
        setTeachers(prev => prev.map(t => t.id === id ? { ...t, ...cleanUpdates } : t));
    };

    const deleteTeacher = (id: string) => {
        setTeachers(prev => prev.filter(t => t.id !== id));
    };

    const updateSettings = (updates: Partial<SchoolSettings>) => {
        const cleanUpdates = sanitizeObject(updates);
        setSettings(prev => ({ ...prev, ...cleanUpdates }));
    };

    const markAttendance = (newAttendance: Attendance) => {
        setAttendance(prev => {
            const oldRecord = prev.find(a =>
                a.date === newAttendance.date &&
                a.class === newAttendance.class &&
                a.campus === newAttendance.campus
            );

            // Fee Adjustment Protocol
            setStudents(currentStudents => {
                return currentStudents.map(student => {
                    const studentInBatch = newAttendance.records.find(r => r.studentId === student.id);
                    if (!studentInBatch) return student;

                    const oldStatus = oldRecord?.records.find(r => r.studentId === student.id)?.status;
                    const newStatus = studentInBatch.status;

                    let feeAdjustment = 0;
                    if (oldStatus !== 'Absent' && newStatus === 'Absent') feeAdjustment = 50;
                    else if (oldStatus === 'Absent' && newStatus !== 'Absent') feeAdjustment = -50;

                    if (feeAdjustment !== 0) {
                        return { ...student, feesTotal: (student.feesTotal || 0) + feeAdjustment };
                    }
                    return student;
                });
            });

            const filtered = prev.filter(a => !(a.date === newAttendance.date && a.class === newAttendance.class && a.campus === newAttendance.campus));

            // Automated Attendance Notifications
            newAttendance.records.forEach(record => {
                const student = students.find(s => s.id === record.studentId);
                if (student && (record.status === 'Absent' || record.status === 'Late')) {
                    const msg = record.status === 'Absent'
                        ? `Dear Parent, your child ${student.name} is ABSENT today (${newAttendance.date}). Please inform us of the reason. - ${settings.schoolName}`
                        : `Dear Parent, your child ${student.name} arrived LATE today (${newAttendance.date}). Please ensure timely arrival. - ${settings.schoolName}`;

                    sendNotification(student.id, 'Attendance', msg);
                }
            });

            return [...filtered, newAttendance];
        });
    };

    const sendNotification = async (studentId: string, type: 'Attendance' | 'Fee' | 'General', message: string) => {
        const student = students.find(s => s.id === studentId);
        if (!student) return;

        const targetNo = student.whatsappNumber || student.contactFather || student.contactSelf || 'N/A';
        const newNotification: Notification = {
            id: `NTF-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            studentId,
            studentName: student.name,
            type,
            message,
            status: 'Pending',
            date: new Date().toLocaleString(),
            targetNumber: targetNo
        };

        setNotifications(prev => [newNotification, ...prev].slice(0, 100));

        if (targetNo !== 'N/A') {
            try {
                let cleanNumber = targetNo.replace(/\D/g, '');
                if (cleanNumber.startsWith('0')) cleanNumber = '92' + cleanNumber.slice(1);
                else if (!cleanNumber.startsWith('92') && cleanNumber.length === 10) cleanNumber = '92' + cleanNumber;

                fetch('/api/wa/send-message', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ to: cleanNumber, message })
                }).then(async (res) => {
                    if (res.ok) {
                        setNotifications(prev => prev.map(n => n.id === newNotification.id ? { ...n, status: 'Queued' } : n));
                        addAuditLog({
                            user: 'System',
                            action: 'WhatsApp Relay',
                            type: 'System',
                            details: `Neural alert dispatched to ${student.name} (${cleanNumber})`
                        });
                    } else {
                        const errorData = await res.json();
                        setNotifications(prev => prev.map(n => n.id === newNotification.id ? { ...n, status: 'Failed' } : n));
                        addAuditLog({
                            user: 'System',
                            action: 'Relay Failed',
                            type: 'Security',
                            details: errorData.error || `WhatsApp failed for ${student.name}`
                        });
                    }
                }).catch(() => {
                    setNotifications(prev => prev.map(n => n.id === newNotification.id ? { ...n, status: 'Failed' } : n));
                });
            } catch (err) {
                console.error('WhatsApp Relay Error:', err);
            }
        } else {
            addAuditLog({
                user: 'System',
                action: 'Notification Skipped',
                type: 'System',
                details: `No contact data available for ${student.name}`
            });
        }

        console.log(`%c [OUTGOING MESSAGE] To: ${targetNo} | Content: ${message}`, 'background: #25D366; color: white; padding: 2px 5px; border-radius: 4px;');
    };

    const triggerFeeReminders = (className?: string, studentId?: string) => {
        let targets = students.filter(s => (s.feesTotal - s.feesPaid) > 0);

        if (studentId) {
            targets = targets.filter(s => s.id === studentId);
        } else if (className) {
            targets = targets.filter(s => s.class === className);
        }

        targets.forEach(student => {
            const pending = student.feesTotal - student.feesPaid;
            const msg = `Dear Parent, this is a reminder regarding the pending fees of Rs. ${pending} for ${student.name} (${student.id}). Please clear the dues at your earliest convenience. - ${settings.schoolName}`;
            // Send through built-in Baileys Relay
            sendNotification(student.id, 'Fee', msg);
        });
    };

    const updateFeeStructure = (updates: Record<string, number>) => {
        setFeeStructure(prev => ({ ...prev, ...updates }));
    };

    const addClass = (name: string, fee: number) => {
        if (classes.includes(name)) return;
        setClasses(prev => [...prev, name]);
        setFeeStructure(prev => ({ ...prev, [name]: fee }));
    };

    const updateClass = (oldName: string, newName: string, fee: number) => {
        setClasses(prev => prev.map(c => c === oldName ? newName : c));
        setFeeStructure(prev => {
            const next = { ...prev };
            if (oldName !== newName) {
                const oldFee = next[oldName];
                delete next[oldName];
                next[newName] = fee ?? oldFee;
            } else {
                next[newName] = fee;
            }
            return next;
        });
        // Update all students in this class
        if (oldName !== newName) {
            setStudents(prev => prev.map(s => s.class === oldName ? { ...s, class: newName } : s));
        }
    };

    const deleteClass = (name: string) => {
        setClasses(prev => prev.filter(c => c !== name));
        setFeeStructure(prev => {
            const next = { ...prev };
            delete next[name];
            return next;
        });
        setClassSubjects(prev => {
            const next = { ...prev };
            delete next[name];
            return next;
        });
        setClassInCharge(prev => {
            const next = { ...prev };
            delete next[name];
            return next;
        });
    };

    const updateClassSubjects = (className: string, subjects: string[]) => {
        setClassSubjects(prev => ({ ...prev, [className]: subjects }));
    };

    const updateClassInCharge = (className: string, teacherId: string) => {
        setClassInCharge(prev => ({ ...prev, [className]: teacherId }));
    };

    const assignSubjectTeacher = (className: string, subject: string, teacherId: string) => {
        setSubjectTeachers(prev => ({
            ...prev,
            [className]: {
                ...(prev[className] || {}),
                [subject]: teacherId
            }
        }));
    };

    const updateTimetable = (className: string, timetable: WeeklyTimetable) => {
        setTimetables(prev => ({ ...prev, [className]: timetable }));
    };

    const updateAllTimetables = (newTimetables: Record<string, WeeklyTimetable>) => {
        setTimetables(prev => ({ ...prev, ...newTimetables }));
    };

    const addExam = (e: Partial<Exam>) => {
        const newExam: Exam = {
            id: `EXM-${Date.now()}`,
            name: e.name || 'Untitled Exam',
            classes: e.classes || [],
            date: e.date || new Date().toISOString().split('T')[0],
            status: 'In Progress',
            createdAt: new Date().toISOString()
        };
        setExams(prev => [...prev, newExam]);
    };

    const deleteExam = (id: string) => {
        setExams(prev => prev.filter(e => e.id !== id));
        setExamResults(prev => prev.filter(er => er.examId !== id));
    };

    const inputMarks = (examId: string, className: string, studentId: string, subject: string, obtained: number, total: number = 100) => {
        setExamResults(prev => {
            const existing = prev.find(r => r.examId === examId && r.studentId === studentId);
            if (existing) {
                return prev.map(r => r.studentId === studentId && r.examId === examId
                    ? { ...r, marks: { ...r.marks, [subject]: { obtained, total } } }
                    : r
                );
            } else {
                return [...prev, {
                    examId,
                    studentId,
                    className,
                    marks: { [subject]: { obtained, total } },
                    totalObtained: 0,
                    totalPossible: 0,
                    percentage: 0,
                    grade: 'N/A',
                    position: null
                }];
            }
        });
    };

    const finalizeResults = (examId: string, className: string) => {
        const generateRemarks = (_percentage: number, grade: string, position: number | null) => {
            if (position === 1) return "Outstanding! An exemplary performance that sets a standard for the entire class. Keep shining!";
            if (position === 2) return "Brilliant work! Your dedication is clearly visible in your results. Minor refinements will lead to the top spot.";
            if (position === 3) return "Excellent achievement! You have secured a place among the best. Consistency is your key to success.";

            if (grade === 'A+') return "Highly impressive. Your mastery of the curriculum is exceptional. Keep maintaining this elite level.";
            if (grade === 'A') return "Commendable performance. You have a very strong grasp of the subjects. Aim for perfection next time.";
            if (grade === 'B') return "Good, consistent work. You have performed well, but there is still room for further excellence in specific areas.";
            if (grade === 'C') return "Satisfactory performance. You have potential for more; more focused revision will help improve your depth of knowledge.";
            if (grade === 'D') return "Requires attention. Bridging learning gaps now with more dedicated study hours will lead to better future results.";

            return "Significant improvement needed. Consistent study habits and seeking help in difficult topics are highly recommended.";
        };

        setExamResults(prev => {
            const classResults = prev.filter(r => r.examId === examId && r.className === className);

            const calculated = classResults.map(res => {
                const totalObtained = Object.values(res.marks).reduce((sum, m) => sum + m.obtained, 0);
                const totalPossible = Object.values(res.marks).reduce((sum, m) => sum + m.total, 0);
                const percentage = totalPossible > 0 ? (totalObtained / totalPossible) * 100 : 0;

                let grade = 'F';
                if (percentage >= 90) grade = 'A+';
                else if (percentage >= 80) grade = 'A';
                else if (percentage >= 70) grade = 'B';
                else if (percentage >= 60) grade = 'C';
                else if (percentage >= 50) grade = 'D';

                return { ...res, totalObtained, totalPossible, percentage, grade };
            });

            calculated.sort((a, b) => b.percentage - a.percentage);

            const positioned = calculated.map((res, index) => {
                const position = index < 3 ? index + 1 : null;
                return {
                    ...res,
                    position,
                    remarks: generateRemarks(res.percentage, res.grade, position)
                };
            });

            const otherResults = prev.filter(r => !(r.examId === examId && r.className === className));
            return [...otherResults, ...positioned];
        });

        setExams(prev => prev.map(e => e.id === examId ? { ...e, status: 'Finalized' } : e));
    };

    const [currentUser, setCurrentUser] = useState<{ id: string, name: string, role: string } | null>(() => {
        const saved = localStorage.getItem('edunova_current_user');
        return saved ? JSON.parse(saved) : null;
    });

    const addAuditLog = (log: Omit<AuditLog, 'id' | 'timestamp'>) => {
        const newLog: AuditLog = {
            ...log,
            id: `LOG-${Date.now()}`,
            timestamp: new Date().toLocaleString()
        };
        setAuditLogs(prev => [newLog, ...prev].slice(0, 100)); // Keep last 100 logs
    };

    const login = (id: string, role: string) => {
        if (role === 'admin') {
            if (id === 'admin') {
                const user = { id: 'admin', name: 'Super Admin', role: 'admin' };
                setCurrentUser(user);
                localStorage.setItem('edunova_current_user', JSON.stringify(user));
                addAuditLog({
                    user: 'Super Admin',
                    action: 'System Login',
                    type: 'Security',
                    details: 'Admin authenticated successfully.'
                });
                return true;
            }
            return false;
        }

        const teacher = teachers.find(t => t.id === id || t.username === id);
        if (teacher) {
            const user = { id: teacher.id, name: teacher.name, role: 'teacher' };
            setCurrentUser(user);
            localStorage.setItem('edunova_current_user', JSON.stringify(user));
            addAuditLog({
                user: teacher.name,
                action: 'Teacher Login',
                type: 'Security',
                details: `${teacher.name} logged into the portal.`
            });
            return true;
        }
        return false;
    };

    const logout = () => {
        setCurrentUser(null);
        localStorage.removeItem('edunova_current_user');
    };

    const [expenses, setExpenses] = useState<Expense[]>(() => {
        const saved = localStorage.getItem('edunova_expenses');
        return saved ? JSON.parse(saved) : [];
    });

    const [salarySlips, setSalarySlips] = useState<SalarySlip[]>(() => {
        const saved = localStorage.getItem('edunova_salary_slips');
        return saved ? JSON.parse(saved) : [];
    });

    useEffect(() => {
        localStorage.setItem('edunova_expenses', JSON.stringify(expenses));
    }, [expenses]);

    useEffect(() => {
        localStorage.setItem('edunova_salary_slips', JSON.stringify(salarySlips));
    }, [salarySlips]);

    const addExpense = (e: Omit<Expense, 'id'>) => {
        const newExpense = { ...e, id: `EXP-${Date.now()}` };
        setExpenses(prev => [...prev, newExpense as Expense]);
    };

    const deleteExpense = (id: string) => {
        setExpenses(prev => prev.filter(e => e.id !== id));
    };

    const generateSalarySlips = (month: string, year: number) => {
        const slips = teachers
            .filter(t => t.status === 'Active')
            .map(t => ({
                id: `SAL-${t.id}-${month}-${year}`,
                teacherId: t.id,
                month,
                year,
                baseSalary: t.baseSalary || 0,
                allowances: [],
                deductions: [],
                netSalary: t.baseSalary || 0,
                status: 'Pending' as const
            }));
        setSalarySlips(prev => {
            const existingIds = slips.map(s => s.id);
            const filtered = prev.filter(p => !existingIds.includes(p.id));
            return [...filtered, ...slips as SalarySlip[]];
        });
    };

    const updateSalarySlip = (id: string, updates: Partial<SalarySlip>) => {
        setSalarySlips(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
    };

    const importBackup = (data: any) => {
        try {
            if (!data || typeof data !== 'object') throw new Error('Invalid backup format');

            // Sanitize and update each state if present in the backup
            if (data.students) setStudents(sanitizeObject(data.students));
            if (data.teachers) setTeachers(sanitizeObject(data.teachers));
            if (data.settings) setSettings(sanitizeObject(data.settings));
            if (data.attendance) setAttendance(sanitizeObject(data.attendance));
            if (data.feeStructure) setFeeStructure(sanitizeObject(data.feeStructure));
            if (data.classes) setClasses(sanitizeObject(data.classes));
            if (data.periodSettings) setPeriodSettings(sanitizeObject(data.periodSettings));
            if (data.classSubjects) setClassSubjects(sanitizeObject(data.classSubjects));
            if (data.classInCharge) setClassInCharge(sanitizeObject(data.classInCharge));
            if (data.subjectTeachers) setSubjectTeachers(sanitizeObject(data.subjectTeachers));
            if (data.timetables) setTimetables(sanitizeObject(data.timetables));
            if (data.exams) setExams(sanitizeObject(data.exams));
            if (data.examResults) setExamResults(sanitizeObject(data.examResults));
            if (data.notifications) setNotifications(sanitizeObject(data.notifications));
            if (data.auditLogs) setAuditLogs(sanitizeObject(data.auditLogs));
            if (data.expenses) setExpenses(sanitizeObject(data.expenses));
            if (data.salarySlips) setSalarySlips(sanitizeObject(data.salarySlips));

            // Force localStorage sync immediately for peace of mind
            Object.entries(data).forEach(([key, val]) => {
                if (key === 'feeStructure') localStorage.setItem('edunova_fees', JSON.stringify(val));
                else if (key === 'periodSettings') localStorage.setItem('edunova_period_settings', JSON.stringify(val));
                else if (key === 'auditLogs') localStorage.setItem('edunova_audit_logs', JSON.stringify(val));
                else if (key === 'salarySlips') localStorage.setItem('edunova_salary_slips', JSON.stringify(val));
                else localStorage.setItem(`edunova_${key}`, JSON.stringify(val));
            });

            return true;
        } catch (error) {
            console.error('Backup Import Failed:', error);
            return false;
        }
    };

    const addCampus = (c: Omit<Campus, 'id'>) => {
        const newCampus: Campus = {
            ...c,
            id: `CAMP-${Date.now().toString().slice(-6)}`
        };
        setCampuses(prev => [...prev, newCampus]);
        addAuditLog({
            user: 'Admin',
            action: 'New Campus Added',
            details: `Campus: ${c.name}`,
            type: 'System'
        });
    };

    const updateCampus = (id: string, updates: Partial<Campus>) => {
        setCampuses(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
        addAuditLog({
            user: 'Admin',
            action: 'Campus Updated',
            details: `ID: ${id}`,
            type: 'System'
        });
    };

    const deleteCampus = (id: string) => {
        setCampuses(prev => prev.filter(c => c.id !== id));
        addAuditLog({
            user: 'Admin',
            action: 'Campus Deleted',
            details: `ID: ${id}`,
            type: 'Security'
        });
    };

    return (
        <StoreContext.Provider value={{
            students,
            teachers,
            settings,
            attendance,
            feeStructure,
            classes,
            periodSettings,
            updatePeriodSettings,
            addClass,
            updateClass,
            deleteClass,
            addStudent,
            updateStudent,
            deleteStudent,
            addTeacher,
            updateTeacher,
            deleteTeacher,
            updateSettings,
            markAttendance,
            updateFeeStructure,
            classSubjects,
            classInCharge,
            subjectTeachers,
            timetables,
            updateClassSubjects,
            updateClassInCharge,
            assignSubjectTeacher,
            updateTimetable,
            updateAllTimetables,
            promoteStudents,
            exams,
            examResults,
            addExam,
            deleteExam,
            inputMarks,
            finalizeResults,
            currentUser,
            login,
            logout,
            notifications,
            sendNotification,
            triggerFeeReminders,
            auditLogs,
            addAuditLog,
            expenses,
            salarySlips,
            addExpense,
            deleteExpense,
            generateSalarySlips,
            updateSalarySlip,
            importBackup,
            campuses,
            addCampus,
            updateCampus,
            deleteCampus
        }}>
            {children}
        </StoreContext.Provider>
    );
};

export const useStore = () => {
    const context = useContext(StoreContext);
    if (!context) throw new Error('useStore must be used within a StoreProvider');
    return context;
};
