-- SQL Schema for Fee Management & Students
-- Run this in your Supabase SQL Editor

-- 1. Ensure students table has fee-related columns
ALTER TABLE public.students 
ADD COLUMN IF NOT EXISTS monthly_fees NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS fees_total NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS fees_paid NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS payment_history JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS discounts JSONB DEFAULT '[]'::jsonb;

-- 2. Create index for performance
CREATE INDEX IF NOT EXISTS idx_students_fees ON public.students (fees_total, fees_paid);

-- TIP: The system expects the 'students' table to exist. 
-- If you don't have it yet, create a basic one with:
-- CREATE TABLE public.students (
--     id TEXT PRIMARY KEY,
--     name TEXT NOT NULL,
--     class TEXT,
--     campus TEXT,
--     ...
-- );
