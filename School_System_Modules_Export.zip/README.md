# School Management Modules Export

This folder contains premium modules for Fee Management, ID Card Generation, and Fee Vouchers, exported from a professional school management system.

## 📦 What's Included?

1.  **Components**:
    *   `FeeVoucher.tsx`: Single student fee receipt/voucher UI.
    *   `BulkFeeVoucher.tsx`: Logic for printing all class vouchers on A4 landscape.
    *   `IDCardGenerator.tsx`: Professional student/staff ID card generator.
2.  **Pages**:
    *   `Fees.tsx`: Complete Fee Ledger, Billing, and History management.
    *   `Finance.tsx`: Financial analytics and revenue tracking.
3.  **Utils**:
    *   `security.ts`: XSS and SQL injection protection utilities.
4.  **Styles**:
    *   `index.css`: Core design system and glassmorphism styles.

---

## 🚀 How to Integrate (Using Cursor AI)

Follow these steps to add these features to your system:

### Step 1: Install Dependencies
Open your terminal in your project folder and run:
```bash
npm install jspdf jspdf-autotable html2canvas lucide-react sweetalert2
```

### Step 2: Set Up Database
If you are using **Supabase**, run the SQL code in `schema.sql` (found in this folder) inside your Supabase SQL Editor to ensure your tables have the required columns.

### Step 3: Use Cursor to Integrate
1.  Copy the `components`, `pages`, and `utils` folders into your `src` directory.
2.  Open your `App.tsx` (or your main router file).
3.  Open the **Cursor Chat (Ctrl+L)** and type:
    > "I have added some new module files. Please update my routes to include the `Fees` and `Finance` pages, and ensure they use my existing `StoreContext` or `Database` connection. Match the UI colors to my project's theme."

### Step 4: Add Styles
Copy the contents of `styles/index.css` into your main CSS file to get the premium "Glassmorphism" look.

---

## 🛠 Features
*   **Bulk Billing**: Generate tuition fees for all students in one click.
*   **Automatic Reminders**: Integration points for WhatsApp fee reminders.
*   **Professional Printing**: High-quality PDF exports for Vouchers and ID Cards.
*   **Secure**: All financial inputs are sanitized via the included security utils.
